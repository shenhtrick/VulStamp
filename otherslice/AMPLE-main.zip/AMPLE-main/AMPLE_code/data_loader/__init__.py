n_identifier = 'features'
g_identifier = 'structure'
l_identifier = 'label'